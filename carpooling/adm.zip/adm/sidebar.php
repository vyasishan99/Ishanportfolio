<div class="container-fluid admin-content">

    <!-- admin sidebar panel -->
    <div class="row">
        <div class="col-md-2 admin-sidebar">
            <ul class="admin-sidebar-navlink">
                <li><a href="#"><span class="bi bi-person-add fs-5"></span>Manage Customer</a></li>
                <li><a href="#"><span class="bi bi-cart fs-5"></span>Add Category</a></li>
                <li class="dropdown"><a class="dropdown-toggle" data-bs-toggle="dropdown" href="#">Add
                        Subcategory</a></li>
                <ul class="dropdown-menu text-black">
                    <li><a href="#">Add Subcategory</a></li>
                    <li><a href="#">Manage Subcategory</a></li>
                </ul>
                </li>
                <li><a href="#"><span class="bi bi-cart fs-5"></span>Add Products</a></li>
                <li><a href="#">Manage Order <span class="bi bi-truck fs-5">0<span
                                class="badge badge-sm bg-danger"></span></a></li>
                <li><a href="#">Manage Contact <span class="bi bi-telephone fs-5">0<span
                                class="badge badge-sm bg-danger"></span></a></li>
                <li><a href="#">Manage Reviews <span class="bi bi-star fs-5">0<span
                                class="badge badge-sm bg-danger"></span></a></li>
                <li><a href="#">Manage Bill <span class="bi bi-printer fs-5">0<span
                                class="badge badge-sm bg-danger"></span></a></li>
                <li><a href="#">Logout here<span class="bi bi-power fs-5"> <span
                                class="badge badge-sm bg-danger"></span></a></li>
            </ul>
        </div>





